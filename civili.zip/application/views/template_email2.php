<div style="background-color:#f7f8f8;margin:0!important;padding:0">
    <center style="table-layout:fixed;width:100%">
        <div style="margin:0 auto;max-width:680px">
            <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;color:#3c3c3c;font-family:-apple-system,BlinkMacSystemFont,'Neue Haas Grotesk Text Pro','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:17px;margin:0 auto;max-width:680px;width:100%">
                <tbody>
                    <tr>
                        <td style="padding:0;padding-top:34px">
                            <table width="100%" style="border-spacing:0;color:#3c3c3c;font-family:-apple-system,BlinkMacSystemFont,'Neue Haas Grotesk Text Pro','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:17px">
                                <tbody>
                                    <tr>
                                        <td style="padding:0;width:26px"></td>
                                        <td style="padding:0">
                                            <table style="border-spacing:0;color:#3c3c3c;font-family:-apple-system,BlinkMacSystemFont,'Neue Haas Grotesk Text Pro','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:17px">
                                                <tbody>
                                                    <tr>
                                                        <td style="background:#ffffff;border-radius:5px;padding:51px;padding-bottom:47px;padding-top:49px">
                                                            <img src="https://ci3.googleusercontent.com/proxy/uxifnM0eeED4LAJWqwIbWMi907I7qMsg-LRy9bHi2JfpcQRlYSyYZXWNV-ocsUcMi8-VyhAkgfE=s0-d-e1-ft#https://momentumdash.com/img/logo.png" height="60" width="60" style="border:0" class="CToWUd">

                                                            <p style="font-size:30px;font-weight:bold;line-height:130%;margin:0;margin-bottom:27px;margin-top:33px">
                                                                Welcome to Momentum, Li!
                                                            </p>

                                                            <p style="line-height:27px;margin:1em 0">We're happy you're here. Click the button below to activate your account.</p>

                                                            <p style="line-height:27px;margin:29px 0">

                                                                <a href="<?= base_url() . 'auth/verify?email=' . $email . '&token=' . urlencode($token) ?>" style="background-color:#42b3bd;border:0;border-radius:100px;color:#ffffff;display:inline-block;font-size:18px;font-weight:bold;line-height:52px;outline:none;padding:0 42px;text-align:center;text-decoration:none;word-break:break-word" target="_blank" >Activate your account</a>
                                                            </p>
                                                            
                                                            <div style="color:#839ca0;margin-top:41px">
                                                                <p style="font-size:15px;line-height:23px;margin:1em 0">
                                                                    <span style="font-weight:bold">Button above not working?</span><br>
                                                                    Copy and paste this link into your browser:<br>
                                                                    <a href="#m_-6131826731243270749_" rel="nofollow" style="border:0;color:#839ca0;font-weight:normal;outline:none;text-decoration:none"><?= base_url() . 'auth/verify?email=' . $email . '&token=' . urlencode($token) ?></a>
                                                                </p>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="color:#aaaaaa;font-size:12px;padding:0;padding-bottom:43px;padding-top:30px">
                                                          </td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </td>
                                        <td style="padding:0;width:26px"></td>
                                    </tr>
                                </tbody>
                            </table>

                        </td>
                    </tr>
                </tbody>
            </table>


        </div>
    </center>

    <img src="https://ci3.googleusercontent.com/proxy/_eKc78gDpyxczidE-ds9-Ked4NFIJ7cbEOeF-Zlx5Ewd6DUaqhSOTJf4YL6-gfdvMSTroYN2iW_UUxXu-gnC6aACDoj3TF0WNJNGVFO8m6XeKna5aCVPTsyVxCPzYVun92iLYy14GNg=s0-d-e1-ft#https://mandrillapp.com/track/open.php?u=30292706&amp;id=c98e3ff0ad814a8ab387c95b8f96fae1" height="1" width="1" class="CToWUd">
</div>